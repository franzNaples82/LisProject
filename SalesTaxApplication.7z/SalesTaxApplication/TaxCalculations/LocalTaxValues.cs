﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTax.TaxCalculations
{
    public class LocalTaxValues
    {
        public static double BOOK_TAX = 0.0;
        public static double MUSICCD_TAX = 0.0;
        public static double MEDICAL_TAX = 0.0;
        public static double MISC_TAX = 0.10;
    }
}
