﻿using SalesTax.Shopping;
using System;

namespace SalesTaxApplication
{
	class Program
	{
		static void Main(string[] args)
		{

			Console.WriteLine("Input 1");
			ShoppingStore store = new ShoppingStore();
			store.GetSalesOrder();
			store.CheckOut();

			Console.WriteLine("Input 2");

			ShoppingStore store1 = new ShoppingStore();

			store1.RetrieveOrderAndPlaceInCart(store1.GetProductName(), store1.GetProductPrice(), store1.IsProductImported(), store1.GetQuantity());
			store1.IsAddAnotherProduct();
			store1.RetrieveOrderAndPlaceInCart(store1.GetProductName(), store1.GetProductPrice(), store1.IsProductImported(), store1.GetQuantity());
			store1.CheckOutimported();

			Console.WriteLine("Input 3");

			ShoppingStore store2 = new ShoppingStore();
			string s1 = "1 imported bottle of perfume at 27.99";
			string s2 = "1 bottle of perfume at 18.99";
			string s3 = "1 packet of headache pills at 9.75";
			string s4 = "1 box of imported chocolates at 11.25";
			Console.WriteLine(s1);
			Console.WriteLine(s2);
			Console.WriteLine(s3);
			Console.WriteLine(s4);
			store2.CheckOutimportedNew(s1, s2, s3, s4);

			}
	}
}
